﻿using Xamarin.Forms;

namespace PackTrack.PDA
{
    public partial class MainPage : ContentPage
    {
        public MainPage()
        {
            InitializeComponent();

            MessagingCenter.Subscribe<App, string>(this, "ScanBarcode", async (sender, args) =>
            {
                await DisplayAlert("Push message", args.ToString(), "OK");
            });
        }
    }
}
