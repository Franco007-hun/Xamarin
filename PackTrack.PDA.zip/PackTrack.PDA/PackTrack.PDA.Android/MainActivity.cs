﻿using Android.App;
using Android.Content.PM;
using Android.OS;
using Android.Runtime;
using Symbol.XamarinEMDK.Barcode;
using System.Threading;

namespace PackTrack.PDA.Droid
{
    [Activity(Label = "PackTrack.PDA", Icon = "@mipmap/icon", Theme = "@style/MainTheme", MainLauncher = true, ConfigurationChanges = ConfigChanges.ScreenSize | ConfigChanges.Orientation | ConfigChanges.UiMode | ConfigChanges.ScreenLayout | ConfigChanges.SmallestScreenSize)]
    public class MainActivity : global::Xamarin.Forms.Platform.Android.FormsAppCompatActivity
    {
        IBarcodeScannerManager _scannerManager;
       
        protected override void OnCreate(Bundle savedInstanceState)
        {
            TabLayoutResource = Resource.Layout.Tabbar;
            ToolbarResource = Resource.Layout.Toolbar;

            base.OnCreate(savedInstanceState);

            Xamarin.Essentials.Platform.Init(this, savedInstanceState);
            global::Xamarin.Forms.Forms.Init(this, savedInstanceState);

            _scannerManager = new BarcodeScannerManager(this);

            _scannerManager.ScanReceived += OnScanReceived;
            _scannerManager.Enable();
           
            LoadApplication(new App());

            Xamarin.Forms.MessagingCenter.Send<App, string>((App)Xamarin.Forms.Application.Current, "ScanBarcode", "teszt2");
        }
     

        protected override void OnDestroy()
        {
            base.OnDestroy();

            _scannerManager.ScanReceived -= OnScanReceived;
            _scannerManager.Dispose();
            _scannerManager = null;
        }

        void OnScanReceived(object sender, Scanner.DataEventArgs args)
        {
            var scanDataCollection = args.P0;
            if (scanDataCollection?.Result == ScannerResults.Success)
            {
                ThreadPool.QueueUserWorkItem(state =>
                {
                    RunOnUiThread(() => {
                        Xamarin.Forms.MessagingCenter.Send<App, string>((App)Xamarin.Forms.Application.Current, "ScanBarcode", "teszt3");
                    });
                });
            }
        }

        public static void Action() {
            Xamarin.Forms.MessagingCenter.Send<App, string>((App)Xamarin.Forms.Application.Current, "ScanBarcode", "teszt3");
        }
        
        public override void OnRequestPermissionsResult(int requestCode, string[] permissions, [GeneratedEnum] Android.Content.PM.Permission[] grantResults)
        {
            Xamarin.Essentials.Platform.OnRequestPermissionsResult(requestCode, permissions, grantResults);

            base.OnRequestPermissionsResult(requestCode, permissions, grantResults);
        }
    }
}